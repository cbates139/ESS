﻿CREATE VIEW [dbo].[ItemsView]
	AS SELECT * FROM [dbo].[Item]
