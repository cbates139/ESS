﻿CREATE VIEW [dbo].[QuotesView]
	AS SELECT * FROM [dbo].[Quote]
	
