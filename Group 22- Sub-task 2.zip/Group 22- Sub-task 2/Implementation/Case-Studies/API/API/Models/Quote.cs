﻿namespace API.Models
{
    public class Quote : QuoteBase
    {
        public float TotalCost { get; set; }
        public string Description { get; set; }
    }
}
